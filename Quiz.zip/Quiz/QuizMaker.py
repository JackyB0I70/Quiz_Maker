#Quiz Maker
import tkinter as tk
import time
import random

#Create Question Class
class Question:
    def __init__(self, text, ans):
        self.text = text
        self.ans = ans

#Create question objects
Qs = [Question("What is 7 X 7?", "49"),
         Question("What is 8 X 8?", "64")
        ]

random.shuffle(Qs)
Correct_Ans = 0
Question_num = 0

#Functions
def Create_Widgets():
    Start.destroy()
    
    Question_txt = tk.Label(frame, text="", font="bold 20")
    Question_txt.place(x=50, y=20, width=600, height=200)

    Ans_box = tk.Entry(frame, font="bold 15")
    Ans_box.place(x=150, y=250, width=400, height=35)

    Submit = tk.Button(frame, text="next", font="bold 15", command=lambda: Next_Question(Ans_box, Question_txt, Submit))
    Submit.place(x=250, y=300, width=200, height=35)

    Create_Question(Question_txt, Ans_box, Submit)

def Create_Question(Question_txt, Ans_box, Submit):
    global Question_num
    if Question_num == len(Qs):
        Ans_box.place(x=2000)
        Question_txt.place(x=2000)
        Submit.place(x=2000)
        global Correct_Ans
        endsctxt = tk.Label(frame, text=(Correct_Ans, "/", len(Qs)), font="bold 30")
        endsctxt.place(x=250, y=100, width=200, height=50)

    else:
        Chars = [char for char in Qs[Question_num].text]
        count = 0
        string = ""
        for i in range(len(Chars)):
            string = string + Chars[count]
            Question_txt.config(text=string)
            Question_txt.update()
            time.sleep(0.1)
            count = count + 1

def Next_Question(Ans_box, Question_txt, Submit):
    global Question_num
    Ans_txt = Ans_box.get()
    Ans_box.place(x=2000)
    Question_txt.place(x=2000)
    Submit.place(x=2000)
    endtxt = tk.Label(frame, text="", font="bold 25")
    endtxt.place(x=250, y=100, width=200, height=50)
    if Ans_txt == Qs[Question_num].ans:
        global Correct_Ans
        Correct_Ans = Correct_Ans + 1
        Question_num = Question_num + 1
        endtxt.config(text="correct", fg="green")
        endtxt.update()
        time.sleep(1.0)
        endtxt.destroy()
        Question_txt.place(x=50, y=20, width=600, height=200)
        Ans_box.place(x=150, y=250, width=400, height=35)
        Submit.place(x=250, y=300, width=200, height=35)
        Ans_box.delete(0, tk.END)
        Create_Question(Question_txt, Ans_box, Submit)

    else:
        Question_num = Question_num + 1
        endtxt.config(text="wrong", fg="red")
        endtxt.update()
        time.sleep(1.0)
        endtxt.destroy()
        Question_txt.place(x=50, y=20, width=600, height=200)
        Ans_box.place(x=150, y=250, width=400, height=35)
        Submit.place(x=250, y=300, width=200, height=35)
        Ans_box.delete(0, tk.END)
        Create_Question(Question_txt, Ans_box, Submit)

#Create Main Window
frame = tk.Tk()
frame.title("Quiz maker")
frame.geometry("700x500")

titletxt = tk.Label(frame, text="Quiz title", font="bold 25")
titletxt.place(x=250, y=100, width=200, height=50)

Start = tk.Button(frame, text="start", font="bold 20", command=Create_Widgets)
Start.place(x=250, y=250, width=200, height=50)

frame.mainloop()
